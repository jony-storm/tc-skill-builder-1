This webapp is a basic app that uses only pure HTML, CSS and Javascript with some fontawesome icons.
In order to run the app open the "home.html" file or "contact.html" file in any browser.
In challenge I added a navigation bar to the "home.html" and "contact.html" page for nagivating easily from page to page.
The pages are responsive for mobiles, tablets and desktops.
I provided two pdf file to verify the app.
The "preview_desktop.pdf" file is to verify the home page for desktop screen.
The "preview_mobile_tablet.pdf" file is to verify the home page for mobile and tablet screen.