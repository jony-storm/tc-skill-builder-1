This webapp is a basic app that uses only HTML and CSS. In order to run the app open the "index.html" file in a browser.
I provided an "preview.pdf" file to verify the app.