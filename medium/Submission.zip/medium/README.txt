This webapp is a basic app that uses only pure HTML, CSS and Javascript. 
I also used FontAwesome icons. 
The app is responsive for mobiles, tablets and desktops.
In order to run the app open the "contact.html" file in any browser.
In the contact page if you click on the "Submit" button then an alert will be shown 
then the user will be redirected to the home page. If the user click on 
the "cancel" button then the user will be redirected to home page directly.
I provided an "preview.pdf" file to verify the app.